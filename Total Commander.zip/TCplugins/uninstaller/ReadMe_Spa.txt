UnInstaller v1.7.2 - FS-plugin para Total Commander 5.51 y superior
-------------------------------------------------------------------

Plugin mejorado para desinstalar diferentes programas. Semejante al 
Panel de Control - "Agregar\Remover programa", pero m�s poderoso y conveniente.

Capacidades:
------------
   - Muestra todos los registros para desinstalar programas 
     (tambi�n ocultos) 
   - Desinstalar programa                     ("Enter")
   - Ver todas las propiedades del registro   ("F3" o "Ctrl-Q")
   - Eliminar enlaces incorrectos             ("Del" o "F8")
   - Editar algunas propiedades del registro  ("Alt"+"Enter")
   - Configurar plugin                        ("Alt"+"Enter" en Entorno de Red)


Instalaci�n
------------
1. Descomprimir el archivo en un directorio vac�o
2. Elegir Configuraci�n - Opciones - Operaci�n - FS-Plugins
3. Click "Agregar"
4. Ir al directorio donde el archivo fue descomprimido, y seleccionar UnInstTC.wfx
5. Click Aceptar. Ahora puede acceder al plugin en "Entorno de Red"


Disfr�telo
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru
