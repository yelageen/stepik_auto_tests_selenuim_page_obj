UnInstaller v1.7.2 - Connector de SF per al Total Commander 5.51 i superior
-------------------------------------------------------------------

Connector millorat per a desinstal�lar programes. Semblant al
Tauler de Control - "Afegeix\Suprimeix programes", per� amb m�s caracter�stiques.

Caracter�stiques:
------------
   - Mostra tots els registres per a desintal�lar programes
     (tamb� els ocults) 
   - Desinstal�la el programa                      ("Retorn")
   - Visualitza totes les propietats del registre  ("F3" o "Ctrl-Q")
   - Suprimeix enlla�os incorrectes                ("Supr" o "F8")
   - Edita algunes propietats del registre         ("Alt+Retorn")
   - Configura el connector                        ("Alt+Retorn" a Entorn de Xarxa)


Instal�laci�
------------
1. Descomprimiu l'arxiu en un directori buit
2. Seleccioneu Configuraci� - Opcions - Operaci� - FS-Plugins
3. Feu clic a "Afegeix"
4. Aneu al directori on he descomprimit l'arxiu, i seleccioneu UnInstTC.wfx
5. Feu clic a "D'acord". Ja podeu accedir al connector a "Entorn de Xarxa"


Gaudiu-lo
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru

