UnInstaller v1.7.3 - SP (WFX) - wtyczka dla Total Commander 5.51 albo nowszego
------------------------------------------------------------------------------------------------------------------------

Rozszerzona wtyczka do odinstalowywania programu.
Taki sam jak w Panelu sterowania "Dodaj\Usu� programy tylko potrafi wiecej


Opis klawiszy:
----------------------
   - Poka� wszystkie wpisy danego programu 
     (Ukryte tak�e) 
   - Odinstalowanie programu                        	("Enter")
   - Podgl�d danego wpisy  (programu)	("F3" or "Ctrl-Q")
   - Usu� niew�a�ciwt wpis (program)                ("Del" or "F8")
   - Edytuj pewne w�a�ciwo�ci	     	("Alt"+"Enter")
   - Ustawienia wtyczki                            	("Alt"+"Enter" w otoczeniu sieciowym)


Instalacja:
---------------
1. Rozpakuj archiwym do pustego katalogu
2. Wybierz z menu konfiguracja - ustawienia g��wne - Operacje - SP-wtyczka
3. Kliknij  "Dadaj"
4. Wska� ten katalog gdzie rozpakowa�e�/a� ten program i wybierz "UnInstTC.wfx"
5. Nacisnij OK. Mo�esz korzysta� z tego programu klikajac na "Otoczenie Sieciowe"


Pozdrawiam
-------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru

