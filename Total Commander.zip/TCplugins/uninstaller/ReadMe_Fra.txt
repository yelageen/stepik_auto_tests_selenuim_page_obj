UnInstaller v1.7.2 - Additif de Syst�me de Fichiers pour Total Commander 5.51 et plus
----------------------------------------------------------------
Additif avanc� pour d�sinstaller diff�rents logiciels. 
Identique � celui du Panneau de configuration: "Ajouter\Supprimer des Programmes".
Plus simple d'emploi et plus puissant...

Capacit�es:
------------
   - Montre toutes les entr�es a d�sintaller (cach�es �galement)
   
   - D�sinstaller un program                       ("Entr�e")
   - Voir les propri�t�es d'une entr�e    ("F3" or "Ctrl-Q")
   - Supprimer des liens "morts"                ("Del" or "F8")
   - Editer des propri�t�es d'une entr�e ("Alt"+"Entr�e")
   - Configurer l'additif                ("Alt"+"Entr�e" dans le "voisinage r�seau" de TC)


Installation
------------
1. D�zipper l'archive dans un r�pertoire vide
2. Choisir Options->Configuration ->Op�rations: Additif SF
3. Click "Ajouter"
4. S�lectionner UnInstTC.wfx dans le pr�c�dent r�pertoire
5. Click OK. Vous avez maintenant acc�s au plugin dans le "voisinage r�seau"


Amusez vous :)
---------------------
Skarednyi Igor (Gosha)
e-mail: prof@atnet.ru
