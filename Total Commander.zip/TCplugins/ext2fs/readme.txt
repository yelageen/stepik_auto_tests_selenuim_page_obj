ex2fs plugin v1.3 - for Total Commander 5.5 and newer.

This plugin allows to access Linux ext2 partitions and also ReiserFS
partitions from within Windows!

How to install the plugin in Total Commander:
1. Unzip the archive to an empty directory
2. Choose Configuration - Options - Operation - FS-Plugins
3. Click "Add"
4. Go to the "output" subdirectory and choose ex2fs.wfx
5. Click OK. You can now access the plugin in "Network Neighborhood"

IMPORTANT NOTE:

This plugin is based on the open source program Explore2fs.
Therefore this plugin is open source too. Please read the
file Copying.txt in the source directory (in ex2fs_src.zip)!
Any code based on this plugin MUST be open source too!

The source is available separately on our homepage (addons
section).

The codepages can be obtained from Apache project
http://www.apache.org
Russian codepage translation KOI8 -> CP1251 are in project.
To activate codepage just copy it in tables subfolder and
write it's filename in ex2fs.ini file like this:
XLATfile=tables\<codepage>
Then - set variable EnableXLAT to true like this:
EnableXLAT=true

Co-Authors:
Christian Ghisler
http://www.ghisler.com
Sergej Puljajev aka Gorbush
http://gorbush.narod.ru

Changelog:
2005-08-24  Fixed: Wrong time stamps of files shown in list/copied
2005-08-18  Fixed: Sometimes additional bytes at the end of a file copied from the Reiser file system
2004-07-20  Added: Transcoding (Author: Gorbush)
2003-01-27  Fixed: Couldn't enter empty dirs in ReiserFs
2003-01-27  Fixed: Allocated memory not free with ReiserFs
2003-01-27  Fixed: Problems with file sizes in Reiser fs
2003-01-17  Fixed: Integrated new sources from rfstool 0.10
                   (fixes some problems with ReiserFS access)
2002-10-08  Fixed: Couldn't access multiple partitions
2002-10-08  Added: ReiserFS support
2002-10-13  Fixed: Delete .lock file when disconnecting
