The source is available separately on our homepage (addons
section).

Author:
Christian Ghisler
http://www.ghisler.com
